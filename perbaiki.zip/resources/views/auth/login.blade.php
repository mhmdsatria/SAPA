<x-layouts.app>
    <div class="mx-auto max-w-md panel p-7">
        <h1 class="text-2xl font-black">Masuk</h1><p class="mt-1 text-sm text-slate-500">Gunakan akun email, Google, atau OTP.</p>
        <form method="POST" action="{{ route('login.store') }}" class="mt-6 space-y-4">@csrf
            <x-ui.input label="Email" name="email" type="email" value="{{ old('email') }}" required autofocus />
            <x-ui.input label="Kata sandi" name="password" type="password" required />
            <x-ui.checkbox label="Ingat saya" name="remember" value="1" />
            <x-ui.button type="submit" class="w-full">Masuk</x-ui.button>
        </form>
        <div class="my-5 flex items-center gap-3 text-xs text-slate-400"><div class="h-px flex-1 bg-slate-200 dark:bg-slate-800"></div>atau<div class="h-px flex-1 bg-slate-200 dark:bg-slate-800"></div></div>
        <div class="grid gap-3"><x-ui.button :href="route('google.redirect')" variant="secondary">Masuk dengan Google</x-ui.button><x-ui.button :href="route('otp.create')" variant="secondary">Masuk dengan Email/WhatsApp OTP</x-ui.button></div>
        <p class="mt-5 text-center text-sm text-slate-500">Belum punya akun? <a class="font-bold text-blue-600" href="{{ route('register') }}" wire:navigate>Daftar</a></p>
    </div>
</x-layouts.app>
