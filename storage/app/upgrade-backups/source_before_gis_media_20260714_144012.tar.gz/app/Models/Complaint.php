<?php

namespace App\Models;

use App\Traits\HasLocation;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Storage;

class Complaint extends Model
{
    use HasFactory;
    use HasLocation;

    public const STATUS_PENDING = 'pending';
    public const STATUS_APPROVED = 'approved';
    public const STATUS_REJECTED = 'rejected';

    public const CATEGORY_JALAN = 'jalan';
    public const CATEGORY_KEBERSIHAN = 'kebersihan';
    public const CATEGORY_PENERANGAN = 'penerangan';
    public const CATEGORY_LAINNYA = 'lainnya';

    protected $fillable = [
        'user_id',
        'region_id',
        'moderated_by',
        'title',
        'slug',
        'description',
        'category',
        'latitude',
        'longitude',
        'location',
        'gps_accuracy',
        'location_source',
        'address_text',
        'landmark',
        'image_path',
        'image_original_name',
        'image_mime',
        'image_size',
        'image_hash',
        'image_taken_at',
        'image_age_days',
        'exif_is_stale',
        'status',
        'is_anonymous',
        'is_duplicate_flag',
        'duplicate_of_id',
        'rejected_reason',
        'approved_at',
        'rejected_at',
        'upvotes_count',
        'comments_count',
    ];

    protected function casts(): array
    {
        return [
            'latitude' => 'float',
            'longitude' => 'float',
            'gps_accuracy' => 'float',
            'image_taken_at' => 'datetime',
            'exif_is_stale' => 'boolean',
            'is_anonymous' => 'boolean',
            'is_duplicate_flag' => 'boolean',
            'approved_at' => 'datetime',
            'rejected_at' => 'datetime',
        ];
    }

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    public function moderator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'moderated_by');
    }

    public function duplicateOf(): BelongsTo
    {
        return $this->belongsTo(self::class, 'duplicate_of_id');
    }

    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    public function upvotes(): HasMany
    {
        return $this->hasMany(Upvote::class);
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_APPROVED);
    }

    public function scopeForAdmin(Builder $query, User $user): Builder
    {
        if ($user->isSuperAdmin()) {
            return $query;
        }

        if ($user->isAdminDaerah()) {
            $regionIds = $user->regionalAssignments()->pluck('region_id');

            return $query->whereIn('region_id', $regionIds);
        }

        return $query->whereRaw('1 = 0');
    }

    public function getImageUrlAttribute(): string
    {
        return Storage::disk('public')->url($this->image_path);
    }

    public function getReporterNameAttribute(): string
    {
        return $this->is_anonymous ? 'Pelapor anonim' : ($this->user?->name ?? 'Warga');
    }

    public function getCategoryLabelAttribute(): string
    {
        return match ($this->category) {
            self::CATEGORY_JALAN => 'Jalan Raya',
            self::CATEGORY_KEBERSIHAN => 'Kebersihan',
            self::CATEGORY_PENERANGAN => 'Penerangan',
            default => 'Lainnya',
        };
    }
}
