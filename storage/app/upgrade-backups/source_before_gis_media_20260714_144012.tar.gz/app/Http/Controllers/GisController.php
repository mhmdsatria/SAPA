<?php

namespace App\Http\Controllers;

use App\Models\Complaint;
use App\Models\Region;
use App\Services\GisService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class GisController extends Controller
{
    public function __construct(private readonly GisService $gisService)
    {
    }

    public function complaints(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'category' => ['nullable', Rule::in([
                Complaint::CATEGORY_JALAN,
                Complaint::CATEGORY_KEBERSIHAN,
                Complaint::CATEGORY_PENERANGAN,
                Complaint::CATEGORY_LAINNYA,
            ])],
            'status' => ['nullable', Rule::in([
                Complaint::STATUS_PENDING,
                Complaint::STATUS_APPROVED,
                Complaint::STATUS_REJECTED,
            ])],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date', 'after_or_equal:date_from'],
            'include_all' => ['nullable', 'boolean'],
        ]);

        $user = $request->user();
        $canViewAdministrativeData = $request->boolean('include_all') && $user?->isAdmin();

        $query = Complaint::query()->with('region');

        if ($canViewAdministrativeData) {
            $query->forAdmin($user);
        } else {
            $query->published();
        }

        $complaints = $query
            ->when($validated['category'] ?? null, fn (Builder $builder, string $category): Builder => $builder->where('category', $category))
            ->when(
                $canViewAdministrativeData && ($validated['status'] ?? null),
                fn (Builder $builder, string $status): Builder => $builder->where('status', $status)
            )
            ->when($validated['date_from'] ?? null, fn (Builder $builder, string $date): Builder => $builder->whereDate('created_at', '>=', $date))
            ->when($validated['date_to'] ?? null, fn (Builder $builder, string $date): Builder => $builder->whereDate('created_at', '<=', $date))
            ->latest()
            ->limit(3000)
            ->get();

        return response()->json($this->gisService->complaintFeatureCollection($complaints));
    }

    public function regions(): JsonResponse
    {
        $regions = Region::query()->where('is_active', true)->get();

        return response()->json($this->gisService->regionFeatureCollection($regions));
    }
}
