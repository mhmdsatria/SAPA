<?php

namespace App\Services;

use App\Models\Comment;
use App\Models\Complaint;
use App\Models\Upvote;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

class ComplaintService
{
    public function __construct(
        private readonly ImageService $imageService,
        private readonly GisService $gisService,
        private readonly CensorService $censorService,
    ) {
    }

    public function create(User $user, array $data, UploadedFile $photo): Complaint
    {
        $processedImage = $this->imageService->processComplaintPhoto($photo);

        try {
            return DB::transaction(function () use ($user, $data, $processedImage): Complaint {
                $latitude = (float) $data['latitude'];
                $longitude = (float) $data['longitude'];
                $duplicate = $this->gisService->detectDuplicate($latitude, $longitude);
                $address = trim((string) ($data['address_text'] ?? ''));

                if ($address === '') {
                    $address = $this->gisService->reverseGeocode($latitude, $longitude);
                }

                $description = $this->censorService->censor($data['description']);
                $titleBase = Str::of($description)->squish()->limit(62, '')->toString();
                $title = ucfirst($titleBase ?: 'Laporan warga kategori '.$data['category']);
                $slug = Str::slug($title).'-'.Str::lower(Str::random(7));

                $complaint = new Complaint([
                    'user_id' => $user->id,
                    'region_id' => $data['region_id'] ?? null,
                    'title' => $title,
                    'slug' => $slug,
                    'description' => $description,
                    'category' => $data['category'],
                    'latitude' => $latitude,
                    'longitude' => $longitude,
                    'gps_accuracy' => $data['gps_accuracy'] ?? null,
                    'location_source' => 'browser_geolocation',
                    'address_text' => $address,
                    'landmark' => $this->censorService->censor($data['landmark'] ?? null) ?: null,
                    'status' => Complaint::STATUS_PENDING,
                    'is_anonymous' => (bool) ($data['is_anonymous'] ?? false),
                    'is_duplicate_flag' => $duplicate !== null,
                    'duplicate_of_id' => $duplicate?->id,
                    ...$processedImage,
                ]);
                $complaint->location = Complaint::pointExpression($latitude, $longitude);
                $complaint->save();

                return $complaint->fresh(['user', 'region']);
            });
        } catch (Throwable $exception) {
            $this->imageService->delete($processedImage['image_path'] ?? null);
            throw $exception;
        }
    }

    public function addComment(User $user, Complaint $complaint, string $content): Comment
    {
        abort_unless($complaint->status === Complaint::STATUS_APPROVED, 422, 'Komentar hanya tersedia untuk laporan yang telah disetujui.');

        return DB::transaction(function () use ($user, $complaint, $content): Comment {
            $comment = $complaint->comments()->create([
                'user_id' => $user->id,
                'content' => $this->censorService->censor($content),
            ]);

            $complaint->update(['comments_count' => $complaint->comments()->where('is_hidden', false)->count()]);

            return $comment->load('user');
        });
    }

    public function toggleUpvote(User $user, Complaint $complaint): bool
    {
        abort_unless($complaint->status === Complaint::STATUS_APPROVED, 422, 'Upvote hanya tersedia untuk laporan yang telah disetujui.');

        return DB::transaction(function () use ($user, $complaint): bool {
            $existing = Upvote::query()
                ->where('complaint_id', $complaint->id)
                ->where('user_id', $user->id)
                ->lockForUpdate()
                ->first();

            if ($existing) {
                $existing->delete();
                $active = false;
            } else {
                Upvote::query()->create([
                    'complaint_id' => $complaint->id,
                    'user_id' => $user->id,
                ]);
                $active = true;
            }

            $complaint->update(['upvotes_count' => $complaint->upvotes()->count()]);

            return $active;
        });
    }

    public function approve(User $admin, Complaint $complaint, ?string $editedDescription = null): Complaint
    {
        return DB::transaction(function () use ($admin, $complaint, $editedDescription): Complaint {
            $values = [
                'status' => Complaint::STATUS_APPROVED,
                'moderated_by' => $admin->id,
                'approved_at' => now(),
                'rejected_at' => null,
                'rejected_reason' => null,
            ];

            if ($editedDescription !== null) {
                $values['description'] = $this->censorService->censor($editedDescription);
            }

            $complaint->update($values);

            return $complaint->fresh(['user', 'region', 'moderator']);
        });
    }

    public function reject(User $admin, Complaint $complaint, string $reason): Complaint
    {
        $complaint->update([
            'status' => Complaint::STATUS_REJECTED,
            'moderated_by' => $admin->id,
            'rejected_reason' => $this->censorService->censor($reason),
            'rejected_at' => now(),
            'approved_at' => null,
        ]);

        return $complaint->fresh(['user', 'region', 'moderator']);
    }

    public function hideComment(User $admin, Comment $comment, bool $hidden = true): Comment
    {
        $comment->update([
            'is_hidden' => $hidden,
            'hidden_by' => $hidden ? $admin->id : null,
            'hidden_at' => $hidden ? now() : null,
        ]);

        $comment->complaint()->update([
            'comments_count' => $comment->complaint->comments()->where('is_hidden', false)->count(),
        ]);

        return $comment->fresh(['user', 'hiddenBy']);
    }
}
