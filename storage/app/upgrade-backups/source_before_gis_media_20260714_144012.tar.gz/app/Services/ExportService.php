<?php

namespace App\Services;

use App\Exports\ComplaintsExport;
use App\Models\Complaint;
use App\Models\User;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Facades\Excel;

class ExportService
{
    public function query(User $admin, array $filters): Builder
    {
        return Complaint::query()
            ->forAdmin($admin)
            ->with(['user', 'region', 'moderator'])
            ->when($filters['date_from'] ?? null, fn (Builder $query, string $date): Builder => $query->whereDate('created_at', '>=', $date))
            ->when($filters['date_to'] ?? null, fn (Builder $query, string $date): Builder => $query->whereDate('created_at', '<=', $date))
            ->when($filters['category'] ?? null, fn (Builder $query, string $category): Builder => $query->where('category', $category))
            ->when($filters['status'] ?? null, fn (Builder $query, string $status): Builder => $query->where('status', $status))
            ->latest();
    }

    public function excel(User $admin, array $filters): mixed
    {
        $rows = $this->query($admin, $filters)->get();

        return Excel::download(
            new ComplaintsExport($rows),
            'rekap-keluhan-'.now()->format('Ymd-His').'.xlsx'
        );
    }

    public function pdf(User $admin, array $filters): mixed
    {
        $rows = $this->query($admin, $filters)->get();

        return Pdf::loadView('exports.complaints-pdf', [
            'complaints' => $rows,
            'filters' => $filters,
        ])
            ->setPaper('a4', 'landscape')
            ->download('rekap-keluhan-'.now()->format('Ymd-His').'.pdf');
    }
}
