<?php

namespace App\Livewire\Public;

use App\Models\Complaint;
use App\Services\CensorService;
use App\Services\ComplaintService;
use App\Services\GisService;
use Illuminate\Http\UploadedFile;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Layout('layouts.app')]
#[Title('Buat Laporan')]
class ComplaintWizard extends Component
{
    use WithFileUploads;

    public int $step = 1;
    public ?UploadedFile $photo = null;
    public string $category = Complaint::CATEGORY_JALAN;

    #[Locked]
    public ?float $latitude = null;

    #[Locked]
    public ?float $longitude = null;

    #[Locked]
    public ?float $gpsAccuracy = null;

    #[Locked]
    public string $addressText = '';

    public bool $locationDetected = false;
    public bool $locationConfirmed = false;
    public string $landmark = '';
    public string $description = '';
    public bool $isAnonymous = false;
    public string $censoredPreview = '';

    public function updatedDescription(CensorService $censorService): void
    {
        $this->censoredPreview = $censorService->censor($this->description);
    }

    public function nextStep(): void
    {
        if ($this->step === 1) {
            $this->validate([
                'photo' => ['required', 'image', 'mimes:jpeg,jpg,png,webp', 'max:10240'],
            ]);
            $this->step = 2;

            return;
        }

        if ($this->step === 2) {
            $this->confirmLocation();
        }
    }

    public function previousStep(): void
    {
        $this->step = max(1, $this->step - 1);
    }

    public function captureLocation(float $latitude, float $longitude, ?float $accuracy, GisService $gisService): void
    {
        validator(
            ['latitude' => $latitude, 'longitude' => $longitude, 'accuracy' => $accuracy],
            [
                'latitude' => ['required', 'numeric', 'between:-90,90'],
                'longitude' => ['required', 'numeric', 'between:-180,180'],
                'accuracy' => ['nullable', 'numeric', 'min:0', 'max:5000'],
            ]
        )->validate();

        $this->latitude = round($latitude, 7);
        $this->longitude = round($longitude, 7);
        $this->gpsAccuracy = $accuracy !== null ? round($accuracy, 2) : null;
        $this->addressText = $gisService->reverseGeocode($this->latitude, $this->longitude);
        $this->locationDetected = true;
        $this->locationConfirmed = false;

        $this->dispatch('wizard-map-location',
            latitude: $this->latitude,
            longitude: $this->longitude,
            accuracy: $this->gpsAccuracy,
        );
    }

    public function confirmLocation(): void
    {
        if (! $this->locationDetected || $this->latitude === null || $this->longitude === null) {
            $this->addError('location', 'Aktifkan GPS dan ambil lokasi terlebih dahulu.');

            return;
        }

        $this->locationConfirmed = true;
        $this->step = 3;
    }

    public function submit(ComplaintService $complaintService): mixed
    {
        $this->validate([
            'photo' => ['required', 'image', 'mimes:jpeg,jpg,png,webp', 'max:10240'],
            'category' => ['required', Rule::in([
                Complaint::CATEGORY_JALAN,
                Complaint::CATEGORY_KEBERSIHAN,
                Complaint::CATEGORY_PENERANGAN,
                Complaint::CATEGORY_LAINNYA,
            ])],
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'gpsAccuracy' => ['nullable', 'numeric', 'min:0', 'max:5000'],
            'addressText' => ['required', 'string', 'max:1000'],
            'landmark' => ['nullable', 'string', 'max:500'],
            'description' => ['required', 'string', 'min:10', 'max:2000'],
            'isAnonymous' => ['boolean'],
            'locationConfirmed' => ['accepted'],
        ], [
            'locationConfirmed.accepted' => 'Lokasi GPS harus dikonfirmasi.',
        ]);

        $complaint = $complaintService->create(auth()->user(), [
            'category' => $this->category,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'gps_accuracy' => $this->gpsAccuracy,
            'address_text' => $this->addressText,
            'landmark' => $this->landmark,
            'description' => $this->description,
            'is_anonymous' => $this->isAnonymous,
        ], $this->photo);

        session()->flash(
            'success',
            $complaint->is_duplicate_flag
                ? 'Laporan tersimpan dan ditandai sebagai kemungkinan duplikat untuk ditinjau admin.'
                : 'Laporan berhasil dikirim dan menunggu moderasi admin.'
        );

        return $this->redirectRoute('profile', navigate: true);
    }

    public function render()
    {
        return view('livewire.public.complaint-wizard');
    }
}
