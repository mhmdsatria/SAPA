<?php

namespace App\Livewire\Public;

use App\Models\Complaint;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('layouts.app')]
#[Title('Beranda')]
class HomePage extends Component
{
    use WithPagination;

    public string $category = '';
    public string $search = '';

    protected $queryString = [
        'category' => ['except' => ''],
        'search' => ['except' => ''],
    ];

    public function updatedCategory(): void
    {
        $this->resetPage();
    }

    public function updatedSearch(): void
    {
        $this->resetPage();
    }

    public function render()
    {
        $complaints = Complaint::query()
            ->published()
            ->with(['user', 'region'])
            ->when($this->category !== '', fn (Builder $query): Builder => $query->where('category', $this->category))
            ->when($this->search !== '', function (Builder $query): Builder {
                $term = '%'.trim($this->search).'%';

                return $query->where(function (Builder $nested) use ($term): void {
                    $nested->where('title', 'like', $term)
                        ->orWhere('description', 'like', $term)
                        ->orWhere('address_text', 'like', $term);
                });
            })
            ->latest('approved_at')
            ->paginate(8);

        $stats = [
            'approved' => Complaint::query()->published()->count(),
            'pending' => Complaint::query()->where('status', Complaint::STATUS_PENDING)->count(),
            'upvotes' => (int) Complaint::query()->published()->sum('upvotes_count'),
        ];

        return view('livewire.public.home-page', [
            'complaints' => $complaints,
            'stats' => $stats,
            'mapEndpoint' => route('gis.complaints', array_filter(['category' => $this->category])),
        ]);
    }
}
