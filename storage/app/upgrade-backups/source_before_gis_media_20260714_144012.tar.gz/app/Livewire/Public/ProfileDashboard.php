<?php

namespace App\Livewire\Public;

use App\Models\Complaint;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('layouts.app')]
#[Title('Profil Warga')]
class ProfileDashboard extends Component
{
    use WithPagination;

    public string $status = '';

    public function updatedStatus(): void
    {
        $this->resetPage();
    }

    public function render()
    {
        $base = Complaint::query()->where('user_id', auth()->id());
        $counts = [
            'all' => (clone $base)->count(),
            'pending' => (clone $base)->where('status', Complaint::STATUS_PENDING)->count(),
            'approved' => (clone $base)->where('status', Complaint::STATUS_APPROVED)->count(),
            'rejected' => (clone $base)->where('status', Complaint::STATUS_REJECTED)->count(),
        ];

        $complaints = Complaint::query()
            ->where('user_id', auth()->id())
            ->with('region')
            ->when($this->status !== '', fn (Builder $query): Builder => $query->where('status', $this->status))
            ->latest()
            ->paginate(10);

        return view('livewire.public.profile-dashboard', compact('counts', 'complaints'));
    }
}
