<?php

namespace App\Livewire\Admin;

use App\Models\Complaint;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('layouts.admin')]
#[Title('Peta Pantau')]
class MonitoringMap extends Component
{
    public string $category = '';
    public string $status = '';
    public string $dateFrom = '';
    public string $dateTo = '';

    public function render()
    {
        $query = array_filter([
            'include_all' => 1,
            'category' => $this->category,
            'status' => $this->status,
            'date_from' => $this->dateFrom,
            'date_to' => $this->dateTo,
        ], fn (mixed $value): bool => $value !== '' && $value !== null);

        return view('livewire.admin.monitoring-map', [
            'mapEndpoint' => route('gis.complaints', $query),
            'statuses' => [
                Complaint::STATUS_PENDING => 'Pending',
                Complaint::STATUS_APPROVED => 'Approved',
                Complaint::STATUS_REJECTED => 'Rejected',
            ],
        ]);
    }
}
