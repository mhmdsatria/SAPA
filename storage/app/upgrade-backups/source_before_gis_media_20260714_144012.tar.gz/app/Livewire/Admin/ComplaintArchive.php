<?php

namespace App\Livewire\Admin;

use App\Models\Complaint;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('layouts.admin')]
#[Title('Arsip Laporan')]
class ComplaintArchive extends Component
{
    use WithPagination;

    public string $search = '';
    public string $status = '';
    public string $category = '';
    public string $dateFrom = '';
    public string $dateTo = '';

    public function updated(string $property): void
    {
        if (in_array($property, ['search', 'status', 'category', 'dateFrom', 'dateTo'], true)) {
            $this->resetPage();
        }
    }

    public function resetFilters(): void
    {
        $this->reset(['search', 'status', 'category', 'dateFrom', 'dateTo']);
        $this->resetPage();
    }

    public function exportQuery(): array
    {
        return array_filter([
            'date_from' => $this->dateFrom,
            'date_to' => $this->dateTo,
            'category' => $this->category,
            'status' => $this->status,
        ]);
    }

    public function render()
    {
        $complaints = Complaint::query()
            ->forAdmin(auth()->user())
            ->with(['user', 'region', 'moderator'])
            ->when($this->search !== '', function (Builder $query): Builder {
                $term = '%'.trim($this->search).'%';

                return $query->where(function (Builder $nested) use ($term): void {
                    $nested->where('title', 'like', $term)
                        ->orWhere('address_text', 'like', $term)
                        ->orWhereHas('user', fn (Builder $userQuery) => $userQuery->where('name', 'like', $term));
                });
            })
            ->when($this->status !== '', fn (Builder $query): Builder => $query->where('status', $this->status))
            ->when($this->category !== '', fn (Builder $query): Builder => $query->where('category', $this->category))
            ->when($this->dateFrom !== '', fn (Builder $query): Builder => $query->whereDate('created_at', '>=', $this->dateFrom))
            ->when($this->dateTo !== '', fn (Builder $query): Builder => $query->whereDate('created_at', '<=', $this->dateTo))
            ->latest()
            ->paginate(15);

        return view('livewire.admin.complaint-archive', [
            'complaints' => $complaints,
            'excelUrl' => route('admin.export.excel', $this->exportQuery()),
            'pdfUrl' => route('admin.export.pdf', $this->exportQuery()),
        ]);
    }
}
