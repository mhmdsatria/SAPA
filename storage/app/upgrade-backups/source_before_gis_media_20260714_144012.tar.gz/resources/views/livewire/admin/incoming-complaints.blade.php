<div class="space-y-6">
    <div><p class="text-sm font-bold text-blue-600">Moderasi cepat</p><h1 class="text-3xl font-black">Laporan Masuk</h1><p class="mt-1 text-slate-500">Tinjau bukti foto, lokasi, indikator EXIF, dan kedekatan spasial sebelum publikasi.</p></div>

    <div class="space-y-5">
        @forelse($complaints as $complaint)
            <article class="panel overflow-hidden" wire:key="incoming-{{ $complaint->id }}">
                <div class="grid gap-5 p-5 xl:grid-cols-[260px_1fr]">
                    <img src="{{ $complaint->image_url }}" class="h-64 w-full rounded-xl object-cover" alt="{{ $complaint->title }}">
                    <div class="space-y-4">
                        <div class="flex flex-wrap items-center gap-2"><x-badge.category :category="$complaint->category" />
                            @if($complaint->exif_is_stale)<span class="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-black text-amber-800">⚠️ Foto {{ $complaint->image_age_days }} hari</span>@endif
                            @if($complaint->is_duplicate_flag)<span class="rounded-full bg-violet-100 px-2.5 py-1 text-xs font-black text-violet-800">Duplikat ≤15 m</span>@endif
                        </div>
                        <div><h2 class="text-xl font-black">{{ $complaint->title }}</h2><p class="mt-1 text-sm text-slate-500">{{ $complaint->user->name }} · {{ $complaint->created_at->format('d M Y H:i') }}</p></div>
                        <dl class="grid gap-3 text-sm sm:grid-cols-2"><div><dt class="text-slate-500">Alamat</dt><dd class="font-semibold">{{ $complaint->address_text }}</dd></div><div><dt class="text-slate-500">Koordinat</dt><dd class="font-mono">{{ $complaint->latitude }}, {{ $complaint->longitude }}</dd></div><div><dt class="text-slate-500">Akurasi GPS</dt><dd class="font-semibold">{{ $complaint->gps_accuracy ? number_format($complaint->gps_accuracy, 0).' m' : 'Tidak tersedia' }}</dd></div><div><dt class="text-slate-500">EXIF diambil</dt><dd class="font-semibold">{{ $complaint->image_taken_at?->format('d M Y H:i') ?? 'Tidak tersedia' }}</dd></div></dl>
                        @if($complaint->duplicateOf)<p class="rounded-xl bg-violet-50 p-3 text-sm text-violet-800 dark:bg-violet-950/30 dark:text-violet-200">Kemungkinan sama dengan: <a class="font-bold underline" href="{{ route('complaints.show', $complaint->duplicateOf) }}" wire:navigate>{{ $complaint->duplicateOf->title }}</a></p>@endif
                        <x-ui.textarea label="Redaksi laporan" wire:model="editDescription.{{ $complaint->id }}" rows="4"></x-ui.textarea>
                        <div class="grid gap-3 sm:grid-cols-[1fr_auto_auto]">
                            <x-ui.input wire:model="rejectReason.{{ $complaint->id }}" placeholder="Alasan penolakan" />
                            <x-ui.button variant="danger" wire:click="reject({{ $complaint->id }})" wire:confirm="Tolak laporan ini?">Reject</x-ui.button>
                            <x-ui.button variant="secondary" wire:click="editAndApprove({{ $complaint->id }})">Edit & Approve</x-ui.button>
                        </div>
                        <div class="flex justify-end"><x-ui.button variant="success" wire:click="approve({{ $complaint->id }})" wire:confirm="Setujui dan publikasikan laporan ini?">Approve</x-ui.button></div>
                    </div>
                </div>
            </article>
        @empty
            <div class="panel p-12 text-center"><p class="text-4xl">✅</p><p class="mt-3 font-bold">Antrean moderasi kosong.</p></div>
        @endforelse
    </div>
    {{ $complaints->links() }}
</div>
