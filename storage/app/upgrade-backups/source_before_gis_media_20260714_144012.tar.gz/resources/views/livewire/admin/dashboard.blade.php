<div class="space-y-7">
    <div><p class="text-sm font-bold text-blue-600">Ringkasan operasional</p><h1 class="text-3xl font-black">Dashboard Admin</h1><p class="mt-1 text-slate-500">Pantau antrean, indikator EXIF, kemungkinan duplikat, dan distribusi kategori.</p></div>

    <div class="grid grid-cols-2 gap-3 xl:grid-cols-6">
        @foreach([
            ['Total', $stats['total'], 'text-slate-950 dark:text-white'],
            ['Menunggu', $stats['pending'], 'text-amber-500'],
            ['Disetujui', $stats['approved'], 'text-emerald-600'],
            ['Ditolak', $stats['rejected'], 'text-red-600'],
            ['Foto lama', $stats['stale'], 'text-amber-600'],
            ['Duplikat', $stats['duplicate'], 'text-violet-600'],
        ] as [$label, $value, $class])
            <div class="panel p-4"><p class="text-xs font-semibold uppercase tracking-wide text-slate-500">{{ $label }}</p><p class="mt-2 text-3xl font-black {{ $class }}">{{ number_format($value) }}</p></div>
        @endforeach
    </div>

    <div class="grid gap-5 xl:grid-cols-2">
        <section class="panel p-5">
            <h2 class="text-lg font-black">Distribusi kategori</h2>
            <div class="mt-5 space-y-4">
                @foreach(['jalan' => 'Jalan Raya', 'kebersihan' => 'Kebersihan', 'penerangan' => 'Penerangan', 'lainnya' => 'Lainnya'] as $key => $label)
                    @php($value = (int) ($categoryStats[$key] ?? 0))
                    @php($percent = $stats['total'] > 0 ? round(($value / $stats['total']) * 100) : 0)
                    <div><div class="mb-1 flex justify-between text-sm"><span>{{ $label }}</span><strong>{{ $value }}</strong></div><div class="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800"><div class="h-full rounded-full bg-blue-600" style="width: {{ $percent }}%"></div></div></div>
                @endforeach
            </div>
        </section>
        <section class="panel p-5">
            <h2 class="text-lg font-black">Laporan 7 hari terakhir</h2>
            <div class="mt-5 flex h-48 items-end gap-3">
                @php($maxDaily = max(1, (int) $dailyStats->max('total')))
                @foreach($dailyStats as $daily)
                    <div class="flex flex-1 flex-col items-center gap-2"><span class="text-xs font-bold">{{ $daily->total }}</span><div class="w-full rounded-t-lg bg-blue-600" style="height: {{ max(8, round(($daily->total / $maxDaily) * 140)) }}px"></div><span class="text-[10px] text-slate-500">{{ \Carbon\Carbon::parse($daily->report_date)->format('d/m') }}</span></div>
                @endforeach
            </div>
        </section>
    </div>

    <section class="panel overflow-hidden">
        <div class="flex items-center justify-between border-b border-slate-200 p-5 dark:border-slate-800"><h2 class="text-lg font-black">Laporan terbaru</h2><x-ui.button :href="route('admin.complaints.incoming')" variant="secondary" wire:navigate>Buka antrean</x-ui.button></div>
        <div class="divide-y divide-slate-200 dark:divide-slate-800">
            @forelse($recent as $complaint)
                <div class="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between"><div><div class="flex gap-2"><x-badge.category :category="$complaint->category" /><x-badge.status :status="$complaint->status" /></div><p class="mt-2 font-bold">{{ $complaint->title }}</p><p class="text-xs text-slate-500">{{ $complaint->user->name }} · {{ $complaint->created_at->diffForHumans() }}</p></div><a href="{{ route('complaints.show', $complaint) }}" wire:navigate class="text-sm font-bold text-blue-600">Detail</a></div>
            @empty
                <div class="p-8 text-center text-slate-500">Belum ada data.</div>
            @endforelse
        </div>
    </section>
</div>
