<div class="space-y-6">
    <div class="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between"><div><p class="text-sm font-bold text-blue-600">Master data</p><h1 class="text-3xl font-black">Arsip Laporan</h1></div><div class="flex gap-2"><x-ui.button :href="$excelUrl" variant="success">Ekspor Excel</x-ui.button><x-ui.button :href="$pdfUrl" variant="danger">Ekspor PDF</x-ui.button></div></div>

    <div class="panel grid gap-4 p-5 md:grid-cols-2 xl:grid-cols-6">
        <div class="xl:col-span-2"><x-ui.input label="Pencarian" wire:model.live.debounce.350ms="search" placeholder="Judul, alamat, pelapor" /></div>
        <x-ui.select label="Status" wire:model.live="status"><option value="">Semua</option><option value="pending">Menunggu</option><option value="approved">Disetujui</option><option value="rejected">Ditolak</option></x-ui.select>
        <x-ui.select label="Kategori" wire:model.live="category"><option value="">Semua</option><option value="jalan">Jalan Raya</option><option value="kebersihan">Kebersihan</option><option value="penerangan">Penerangan</option><option value="lainnya">Lainnya</option></x-ui.select>
        <x-ui.input label="Dari tanggal" type="date" wire:model.live="dateFrom" />
        <x-ui.input label="Sampai tanggal" type="date" wire:model.live="dateTo" />
        <div class="md:col-span-2 xl:col-span-6"><button wire:click="resetFilters" class="text-sm font-bold text-blue-600">Reset filter</button></div>
    </div>

    <div class="panel overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-100 text-left text-xs uppercase tracking-wide text-slate-600 dark:bg-slate-800 dark:text-slate-300"><tr><th class="p-4">Laporan</th><th class="p-4">Pelapor</th><th class="p-4">Kategori</th><th class="p-4">Status</th><th class="p-4">Indikator</th><th class="p-4">Tanggal</th><th class="p-4"></th></tr></thead>
            <tbody class="divide-y divide-slate-200 dark:divide-slate-800">
                @forelse($complaints as $complaint)
                    <tr><td class="min-w-72 p-4"><p class="font-bold">{{ $complaint->title }}</p><p class="mt-1 line-clamp-1 text-xs text-slate-500">{{ $complaint->address_text }}</p></td><td class="p-4">{{ $complaint->reporter_name }}</td><td class="p-4"><x-badge.category :category="$complaint->category" /></td><td class="p-4"><x-badge.status :status="$complaint->status" /></td><td class="p-4"><div class="flex gap-1">@if($complaint->exif_is_stale)<span title="Foto lama">⚠️</span>@endif @if($complaint->is_duplicate_flag)<span title="Duplikat">♊</span>@endif</div></td><td class="whitespace-nowrap p-4">{{ $complaint->created_at->format('d/m/Y H:i') }}</td><td class="p-4"><a href="{{ route('complaints.show', $complaint) }}" wire:navigate class="font-bold text-blue-600">Detail</a></td></tr>
                @empty<tr><td colspan="7" class="p-10 text-center text-slate-500">Data tidak ditemukan.</td></tr>@endforelse
            </tbody>
        </table>
    </div>
    {{ $complaints->links() }}
</div>
