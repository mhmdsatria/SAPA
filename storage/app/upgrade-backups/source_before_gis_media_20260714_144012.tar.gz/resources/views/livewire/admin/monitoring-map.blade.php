<div class="space-y-6">
    <div>
        <p class="text-sm font-bold text-blue-600">Pemantauan GIS</p>
        <h1 class="text-3xl font-black">Peta Pantau Utama</h1>
        <p class="mt-1 text-slate-500">Gunakan filter status, tanggal, dan kategori untuk membaca pola spasial seluruh laporan dalam kewenangan admin.</p>
    </div>

    <div class="panel grid gap-4 p-5 md:grid-cols-2 xl:grid-cols-4">
        <x-ui.select label="Kategori" wire:model.live="category">
            <option value="">Semua kategori</option>
            <option value="jalan">Jalan Raya</option>
            <option value="kebersihan">Kebersihan</option>
            <option value="penerangan">Penerangan</option>
            <option value="lainnya">Lainnya</option>
        </x-ui.select>

        <x-ui.select label="Status" wire:model.live="status">
            <option value="">Semua status</option>
            @foreach ($statuses as $value => $label)
                <option value="{{ $value }}">{{ $label }}</option>
            @endforeach
        </x-ui.select>

        <x-ui.input label="Dari tanggal" type="date" wire:model.live="dateFrom" />
        <x-ui.input label="Sampai tanggal" type="date" wire:model.live="dateTo" />
    </div>

    <div wire:key="admin-map-{{ md5($mapEndpoint) }}">
        <x-map.leaflet
            :endpoint="$mapEndpoint"
            :region-endpoint="route('gis.regions')"
            :fit-regions="true"
            height="680px"
        />
    </div>
</div>
