<div class="space-y-7">
    <div class="grid gap-7 lg:grid-cols-[1.15fr_.85fr]">
        <section class="space-y-5">
            <img src="{{ $complaint->image_url }}" alt="{{ $complaint->title }}" class="max-h-[620px] w-full rounded-2xl bg-slate-100 object-contain dark:bg-slate-900">
            <div class="panel p-6">
                <div class="flex flex-wrap gap-2"><x-badge.category :category="$complaint->category" /><x-badge.status :status="$complaint->status" />
                    @if($complaint->exif_is_stale)<span class="rounded-full bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-800">⚠️ EXIF lebih dari 7 hari</span>@endif
                    @if($complaint->is_duplicate_flag)<span class="rounded-full bg-violet-100 px-2.5 py-1 text-xs font-bold text-violet-800">Kemungkinan duplikat</span>@endif
                </div>
                <h1 class="mt-4 text-3xl font-black">{{ $complaint->title }}</h1>
                <p class="mt-4 whitespace-pre-line leading-7 text-slate-700 dark:text-slate-200">{{ $complaint->description }}</p>
                <dl class="mt-6 grid gap-4 border-t border-slate-200 pt-5 text-sm dark:border-slate-800 sm:grid-cols-2">
                    <div><dt class="text-slate-500">Pelapor</dt><dd class="font-bold">{{ $complaint->reporter_name }}</dd></div>
                    <div><dt class="text-slate-500">Dikirim</dt><dd class="font-bold">{{ $complaint->created_at->timezone(config('app.timezone'))->format('d M Y, H:i') }}</dd></div>
                    <div class="sm:col-span-2"><dt class="text-slate-500">Alamat</dt><dd class="font-bold">{{ $complaint->address_text }} @if($complaint->landmark) · {{ $complaint->landmark }} @endif</dd></div>
                    <div><dt class="text-slate-500">Koordinat</dt><dd class="font-mono">{{ number_format($complaint->latitude, 7) }}, {{ number_format($complaint->longitude, 7) }}</dd></div>
                    <div><dt class="text-slate-500">Foto diambil</dt><dd class="font-bold">{{ $complaint->image_taken_at?->format('d M Y, H:i') ?? 'Metadata tidak tersedia' }}</dd></div>
                </dl>
                @if($complaint->status === 'rejected' && auth()->id() === $complaint->user_id)
                    <div class="mt-5 rounded-xl bg-red-50 p-4 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300"><strong>Alasan penolakan:</strong> {{ $complaint->rejected_reason }}</div>
                @endif
            </div>
        </section>

        <aside class="space-y-5">
            <x-map.leaflet :center="[$complaint->latitude, $complaint->longitude]" :zoom="17" :always-show-markers="true" :points="[[
                'latitude' => $complaint->latitude,
                'longitude' => $complaint->longitude,
                'color' => config('gis.category_colors')[$complaint->category] ?? '#2563eb',
                'popup' => $complaint->title,
            ]]" height="360px" />
            <div class="panel p-5">
                <button wire:click="toggleUpvote" class="flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-3 font-bold transition {{ $hasUpvoted ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-300 hover:border-blue-500 dark:border-slate-700' }}">
                    ▲ {{ $hasUpvoted ? 'Didukung' : 'Dukung laporan' }} · {{ $complaint->upvotes_count }}
                </button>
            </div>
        </aside>
    </div>

    @if($complaint->status === 'approved')
        <section class="mx-auto max-w-4xl space-y-5">
            <div><h2 class="text-2xl font-black">Komentar publik</h2><p class="text-sm text-slate-500">Komentar kasar disensor otomatis dan dapat disembunyikan admin.</p></div>
            @auth
                <form wire:submit="addComment" class="panel space-y-3 p-5">
                    <x-ui.textarea label="Tulis komentar" wire:model.live.debounce.350ms="commentContent" rows="3" placeholder="Berikan informasi tambahan yang relevan."></x-ui.textarea>
                    @error('commentContent')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                    @if($commentPreview !== '' && $commentPreview !== $commentContent)<p class="rounded-lg bg-amber-50 p-2 text-sm text-amber-800">Pratinjau sensor: {{ $commentPreview }}</p>@endif
                    <div class="flex justify-end"><x-ui.button type="submit">Kirim komentar</x-ui.button></div>
                </form>
            @else
                <div class="panel p-5 text-sm"><a href="{{ route('login') }}" wire:navigate class="font-bold text-blue-600">Masuk</a> untuk memberi dukungan dan komentar.</div>
            @endauth

            <div class="space-y-3">
                @forelse($comments as $comment)
                    <article class="panel p-5 {{ $comment->is_hidden ? 'opacity-60' : '' }}">
                        <div class="flex items-start justify-between gap-4">
                            <div><p class="font-bold">{{ $comment->user->name }}</p><p class="text-xs text-slate-500">{{ $comment->created_at->diffForHumans() }}</p></div>
                            @can('hide', $comment)
                                <button wire:click="toggleCommentVisibility({{ $comment->id }})" class="text-xs font-bold text-blue-600">{{ $comment->is_hidden ? 'Tampilkan' : 'Sembunyikan' }}</button>
                            @endcan
                        </div>
                        <p class="mt-3 whitespace-pre-line text-sm leading-6">{{ $comment->is_hidden ? '[Komentar disembunyikan admin]' : $comment->content }}</p>
                    </article>
                @empty
                    <div class="panel p-8 text-center text-slate-500">Belum ada komentar.</div>
                @endforelse
            </div>
        </section>
    @endif
</div>
