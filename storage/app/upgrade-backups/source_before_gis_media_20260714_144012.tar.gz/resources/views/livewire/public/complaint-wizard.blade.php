<div class="mx-auto max-w-3xl space-y-6">
    <div>
        <p class="text-sm font-bold text-blue-600">Wizard pelaporan</p>
        <h1 class="text-3xl font-black">Buat laporan baru</h1>
        <p class="mt-2 text-slate-500">Foto dan koordinat GPS akan dikunci sebagai bukti awal laporan.</p>
    </div>

    <ol class="grid grid-cols-3 gap-3">
        @foreach ([1 => 'Media', 2 => 'Lokasi', 3 => 'Detail'] as $number => $label)
            <li class="rounded-xl border px-3 py-3 text-center text-sm font-bold {{ $step >= $number ? 'border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300' : 'border-slate-200 text-slate-400 dark:border-slate-800' }}">
                <span class="mr-1">{{ $number }}.</span>{{ $label }}
            </li>
        @endforeach
    </ol>

    <div class="panel p-5 sm:p-7">
        @if ($step === 1)
            <div class="space-y-5">
                <div>
                    <h2 class="text-xl font-black">Langkah 1 · Unggah media</h2>
                    <p class="mt-1 text-sm text-slate-500">Gunakan kamera langsung atau pilih foto dari galeri. Format JPEG, PNG, atau WebP maksimal 10 MB.</p>
                </div>
                <label class="block cursor-pointer rounded-2xl border-2 border-dashed border-slate-300 p-6 text-center transition hover:border-blue-500 dark:border-slate-700">
                    <input type="file" wire:model="photo" accept="image/jpeg,image/png,image/webp" capture="environment" class="sr-only">
                    <span class="text-4xl">📷</span>
                    <span class="mt-3 block font-bold">Jepret atau pilih foto</span>
                    <span class="mt-1 block text-sm text-slate-500">Metadata EXIF akan dianalisis otomatis.</span>
                </label>
                <div wire:loading wire:target="photo" class="text-sm font-semibold text-blue-600">Mengunggah foto…</div>
                @error('photo')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                @if ($photo)
                    <img src="{{ $photo->temporaryUrl() }}" class="max-h-[420px] w-full rounded-2xl object-contain bg-slate-100 dark:bg-slate-800" alt="Pratinjau foto">
                @endif
                <div class="flex justify-end"><x-ui.button wire:click="nextStep" wire:loading.attr="disabled">Lanjut ke lokasi</x-ui.button></div>
            </div>
        @elseif ($step === 2)
            <div class="space-y-5" x-data="{
                locating: false,
                locationError: '',
                locate() {
                    this.locationError = '';
                    if (!navigator.geolocation) { this.locationError = 'Perangkat tidak mendukung geolokasi.'; return; }
                    this.locating = true;
                    navigator.geolocation.getCurrentPosition(
                        position => {
                            $wire.captureLocation(position.coords.latitude, position.coords.longitude, position.coords.accuracy)
                                .finally(() => this.locating = false);
                        },
                        error => {
                            this.locating = false;
                            this.locationError = error.message || 'Lokasi tidak dapat diambil. Pastikan izin GPS aktif.';
                        },
                        { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
                    );
                }
            }">
                <div>
                    <h2 class="text-xl font-black">Langkah 2 · Konfirmasi lokasi</h2>
                    <p class="mt-1 text-sm text-slate-500">Koordinat hanya diambil melalui Geolocation API dan tidak tersedia sebagai kolom ketik manual.</p>
                </div>
                <x-ui.button type="button" @click="locate()" x-bind:disabled="locating">
                    <span x-show="!locating">📍 Ambil lokasi GPS</span><span x-show="locating" x-cloak>Mengambil lokasi…</span>
                </x-ui.button>
                <p x-show="locationError" x-text="locationError" x-cloak class="rounded-xl bg-red-50 p-3 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300"></p>
                @error('location')<p class="text-sm text-red-600">{{ $message }}</p>@enderror

                <x-map.leaflet :always-show-markers="true" :center="$latitude !== null ? [$latitude, $longitude] : null" :zoom="$latitude !== null ? 17 : 12" height="420px" />

                @if ($locationDetected)
                    <div class="grid gap-3 sm:grid-cols-2">
                        <div class="rounded-xl bg-slate-100 p-3 dark:bg-slate-800"><p class="text-xs text-slate-500">Latitude</p><p class="font-mono font-bold">{{ number_format($latitude, 7, '.', '') }}</p></div>
                        <div class="rounded-xl bg-slate-100 p-3 dark:bg-slate-800"><p class="text-xs text-slate-500">Longitude</p><p class="font-mono font-bold">{{ number_format($longitude, 7, '.', '') }}</p></div>
                    </div>
                    <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-900 dark:bg-emerald-950/30">
                        <p class="text-xs font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">Alamat hasil reverse geocoding</p>
                        <p class="mt-1 text-sm">{{ $addressText }}</p>
                        @if ($gpsAccuracy !== null)<p class="mt-1 text-xs text-slate-500">Akurasi perangkat sekitar {{ number_format($gpsAccuracy, 0) }} meter.</p>@endif
                    </div>
                @endif
                <div class="flex justify-between gap-3">
                    <x-ui.button variant="secondary" wire:click="previousStep">Kembali</x-ui.button>
                    <x-ui.button wire:click="confirmLocation" :disabled="!$locationDetected">Konfirmasi titik</x-ui.button>
                </div>
            </div>
        @else
            <form wire:submit="submit" class="space-y-5">
                <div>
                    <h2 class="text-xl font-black">Langkah 3 · Detail laporan</h2>
                    <p class="mt-1 text-sm text-slate-500">Tambahkan konteks yang ringkas, faktual, dan mudah diverifikasi.</p>
                </div>
                <x-ui.select label="Kategori" wire:model="category">
                    <option value="jalan">Jalan Raya</option>
                    <option value="kebersihan">Kebersihan</option>
                    <option value="penerangan">Penerangan</option>
                    <option value="lainnya">Lainnya</option>
                </x-ui.select>
                @error('category')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                <x-ui.input label="Patokan tambahan" wire:model="landmark" placeholder="Contoh: depan gerbang sekolah" hint="Patokan boleh ditambahkan, tetapi titik GPS tidak dapat diubah." />
                @error('landmark')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                <x-ui.textarea label="Deskripsi singkat" wire:model.live.debounce.350ms="description" rows="5" placeholder="Jelaskan kondisi, dampak, dan waktu kejadian."></x-ui.textarea>
                @error('description')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                @if ($censoredPreview !== '' && $censoredPreview !== $description)
                    <div class="rounded-xl bg-amber-50 p-3 text-sm text-amber-800 dark:bg-amber-950/40 dark:text-amber-200"><strong>Pratinjau setelah sensor:</strong> {{ $censoredPreview }}</div>
                @endif
                <x-ui.checkbox label="Sembunyikan nama saya pada tampilan publik" wire:model="isAnonymous" />
                @error('locationConfirmed')<p class="text-sm text-red-600">{{ $message }}</p>@enderror
                <div class="flex justify-between gap-3">
                    <x-ui.button type="button" variant="secondary" wire:click="previousStep">Kembali</x-ui.button>
                    <x-ui.button type="submit" wire:loading.attr="disabled"><span wire:loading.remove wire:target="submit">Kirim laporan</span><span wire:loading wire:target="submit">Memproses…</span></x-ui.button>
                </div>
            </form>
        @endif
    </div>
</div>
