<div class="space-y-10">
    <section class="grid items-center gap-8 lg:grid-cols-[1.05fr_.95fr]">
        <div>
            <span class="inline-flex rounded-full bg-blue-100 px-3 py-1 text-sm font-bold text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">Pelaporan publik berbasis GIS</span>
            <h1 class="mt-5 text-4xl font-black leading-tight text-slate-950 dark:text-white sm:text-5xl">Laporkan masalah kota dengan foto dan lokasi yang terverifikasi.</h1>
            <p class="mt-5 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-300">Pantau laporan warga secara transparan melalui peta, status moderasi, komentar, dan dukungan publik.</p>
            <div class="mt-7 flex flex-wrap gap-3">
                @auth
                    <x-ui.button :href="route('complaints.create')" wire:navigate>Buat laporan</x-ui.button>
                    <x-ui.button :href="route('profile')" variant="secondary" wire:navigate>Riwayat saya</x-ui.button>
                @else
                    <x-ui.button :href="route('login')" wire:navigate>Masuk untuk melapor</x-ui.button>
                @endauth
            </div>
        </div>
        <div class="grid grid-cols-3 gap-3">
            <div class="panel p-5 text-center"><p class="text-3xl font-black text-emerald-600">{{ number_format($stats['approved']) }}</p><p class="mt-1 text-sm text-slate-500">Dipublikasi</p></div>
            <div class="panel p-5 text-center"><p class="text-3xl font-black text-amber-500">{{ number_format($stats['pending']) }}</p><p class="mt-1 text-sm text-slate-500">Dimoderasi</p></div>
            <div class="panel p-5 text-center"><p class="text-3xl font-black text-blue-600">{{ number_format($stats['upvotes']) }}</p><p class="mt-1 text-sm text-slate-500">Dukungan</p></div>
        </div>
    </section>

    <section class="space-y-4">
        <div class="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div><h2 class="text-2xl font-black">Peta laporan</h2><p class="mt-1 text-sm text-slate-500">Klik poligon wilayah, lalu perbesar peta untuk menampilkan cluster titik laporan.</p></div>
            <div class="w-full md:w-64">
                <x-ui.select label="Kategori peta" wire:model.live="category">
                    <option value="">Semua kategori</option>
                    <option value="jalan">Jalan Raya</option>
                    <option value="kebersihan">Kebersihan</option>
                    <option value="penerangan">Penerangan</option>
                    <option value="lainnya">Lainnya</option>
                </x-ui.select>
            </div>
        </div>
        <div wire:key="public-map-{{ $category }}">
            <x-map.leaflet :endpoint="$mapEndpoint" :region-endpoint="route('gis.regions')" :fit-regions="true" height="560px" />
        </div>
        <div class="flex flex-wrap gap-4 text-xs font-semibold text-slate-600 dark:text-slate-300">
            <span>🔴 Jalan Raya</span><span>🟢 Kebersihan</span><span>🟡 Penerangan</span><span>🔵 Lainnya</span>
        </div>
    </section>

    <section class="space-y-5">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div><h2 class="text-2xl font-black">Linimasa laporan terbaru</h2><p class="text-sm text-slate-500">Hanya laporan yang telah disetujui admin.</p></div>
            <div class="w-full sm:w-72"><x-ui.input label="Cari laporan" wire:model.live.debounce.400ms="search" placeholder="Judul atau alamat" /></div>
        </div>
        @if ($complaints->count())
            <div class="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
                @foreach ($complaints as $complaint)
                    <x-complaint.card :complaint="$complaint" wire:key="complaint-{{ $complaint->id }}" />
                @endforeach
            </div>
            <div>{{ $complaints->links() }}</div>
        @else
            <div class="panel p-10 text-center text-slate-500">Belum ada laporan yang sesuai dengan filter.</div>
        @endif
    </section>
</div>
