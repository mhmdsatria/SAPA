<div class="space-y-7">
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div><p class="text-sm font-bold text-blue-600">Dashboard warga</p><h1 class="text-3xl font-black">Riwayat laporan saya</h1></div>
        <x-ui.button :href="route('complaints.create')" wire:navigate>+ Buat laporan</x-ui.button>
    </div>
    <div class="grid grid-cols-2 gap-3 lg:grid-cols-4">
        @foreach(['all' => 'Semua', 'pending' => 'Menunggu', 'approved' => 'Disetujui', 'rejected' => 'Ditolak'] as $key => $label)
            <button wire:click="$set('status', '{{ $key === 'all' ? '' : $key }}')" class="panel p-4 text-left transition hover:border-blue-500"><p class="text-2xl font-black">{{ $counts[$key] }}</p><p class="text-sm text-slate-500">{{ $label }}</p></button>
        @endforeach
    </div>
    <div class="space-y-4">
        @forelse($complaints as $complaint)
            <article class="panel grid gap-4 overflow-hidden p-4 sm:grid-cols-[160px_1fr_auto] sm:items-center">
                <img src="{{ $complaint->image_url }}" class="h-32 w-full rounded-xl object-cover sm:w-40" alt="{{ $complaint->title }}">
                <div class="min-w-0"><div class="flex flex-wrap gap-2"><x-badge.category :category="$complaint->category" /><x-badge.status :status="$complaint->status" /></div><h2 class="mt-2 truncate text-lg font-bold">{{ $complaint->title }}</h2><p class="mt-1 truncate text-sm text-slate-500">{{ $complaint->address_text }}</p><p class="mt-2 text-xs text-slate-500">{{ $complaint->created_at->format('d M Y H:i') }} · ▲ {{ $complaint->upvotes_count }} · 💬 {{ $complaint->comments_count }}</p></div>
                <x-ui.button :href="route('complaints.show', $complaint)" variant="secondary" wire:navigate>Detail</x-ui.button>
            </article>
        @empty
            <div class="panel p-10 text-center text-slate-500">Belum ada laporan pada status ini.</div>
        @endforelse
    </div>
    {{ $complaints->links() }}
</div>
