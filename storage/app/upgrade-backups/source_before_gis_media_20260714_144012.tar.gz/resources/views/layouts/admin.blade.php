<!doctype html>
<html lang="id" x-data="{ dark: localStorage.getItem('theme') === 'dark', sidebar: false }" x-init="$watch('dark', value => { localStorage.setItem('theme', value ? 'dark' : 'light'); document.documentElement.classList.toggle('dark', value) }); document.documentElement.classList.toggle('dark', dark)">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#0f172a">
    <link rel="manifest" href="/manifest.json">
    <title>{{ $title ?? 'Admin' }} · {{ config('app.name') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @livewireStyles
</head>
<body>
<div class="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
    <aside class="border-r border-slate-800 bg-slate-950 px-4 py-5 text-white">
        <a href="{{ route('admin.dashboard') }}" wire:navigate class="mb-8 flex items-center gap-3 px-2 text-lg font-black">
            <img src="/icons/icon-192.png" class="h-10 w-10 rounded-xl" alt="Logo"> Admin LaporKota
        </a>
        <nav class="space-y-1">
            <a href="{{ route('admin.dashboard') }}" wire:navigate class="block rounded-xl px-3 py-2.5 text-sm font-semibold {{ request()->routeIs('admin.dashboard') ? 'bg-blue-600' : 'text-slate-300 hover:bg-slate-900' }}">Dashboard</a>
            <a href="{{ route('admin.complaints.incoming') }}" wire:navigate class="block rounded-xl px-3 py-2.5 text-sm font-semibold {{ request()->routeIs('admin.complaints.incoming') ? 'bg-blue-600' : 'text-slate-300 hover:bg-slate-900' }}">Laporan Masuk</a>
            <a href="{{ route('admin.complaints.archive') }}" wire:navigate class="block rounded-xl px-3 py-2.5 text-sm font-semibold {{ request()->routeIs('admin.complaints.archive') ? 'bg-blue-600' : 'text-slate-300 hover:bg-slate-900' }}">Arsip Laporan</a>
            <a href="{{ route('admin.map') }}" wire:navigate class="block rounded-xl px-3 py-2.5 text-sm font-semibold {{ request()->routeIs('admin.map') ? 'bg-blue-600' : 'text-slate-300 hover:bg-slate-900' }}">Peta Pantau</a>
            <a href="{{ route('home') }}" wire:navigate class="mt-6 block rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-300 hover:bg-slate-900">Kembali ke Publik</a>
        </nav>
    </aside>
    <div>
        <header class="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
            <div><p class="text-xs uppercase tracking-wider text-slate-500">Administrator</p><p class="font-bold">{{ auth()->user()->name }}</p></div>
            <div class="flex gap-2">
                <button class="rounded-xl p-2 hover:bg-slate-100 dark:hover:bg-slate-800" @click="dark = !dark"><span x-show="!dark">🌙</span><span x-show="dark" x-cloak>☀️</span></button>
                <form method="POST" action="{{ route('logout') }}">@csrf<x-ui.button type="submit" variant="secondary">Keluar</x-ui.button></form>
            </div>
        </header>
        <main class="p-5 lg:p-8">
            <x-flash />
            {{ $slot }}
        </main>
    </div>
</div>
@livewireScripts
</body>
</html>
