@props([
    'id' => 'map-'.\Illuminate\Support\Str::random(8),
    'endpoint' => null,
    'regionEndpoint' => null,
    'center' => null,
    'zoom' => null,
    'points' => [],
    'height' => '520px',
    'alwaysShowMarkers' => false,
    'fitRegions' => false,
])

@php
$config = [
    'endpoint' => $endpoint,
    'regionEndpoint' => $regionEndpoint,
    'center' => $center ?? [config('gis.default_latitude'), config('gis.default_longitude')],
    'zoom' => $zoom ?? config('gis.default_zoom'),
    'points' => $points,
    'markerZoomThreshold' => config('gis.marker_zoom_threshold', 12),
    'alwaysShowMarkers' => $alwaysShowMarkers,
    'fitRegions' => $fitRegions,
];
@endphp

<div x-data='leafletMap(@json($config))' x-init="init()" class="relative overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800">
    <div x-ref="canvas" id="{{ $id }}" style="height: {{ $height }}"></div>
    <div x-show="loading" x-cloak class="absolute inset-x-0 top-3 z-[500] mx-auto w-fit rounded-full bg-white/95 px-3 py-1.5 text-xs font-semibold text-slate-700 shadow dark:bg-slate-900/95 dark:text-slate-200">Memuat data peta…</div>
    <div x-show="error" x-text="error" x-cloak class="absolute inset-x-3 bottom-3 z-[500] rounded-xl bg-red-600 px-3 py-2 text-sm text-white"></div>
</div>
