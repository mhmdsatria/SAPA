@props(['category'])

@php
$classes = match ($category) {
    'jalan' => 'bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300',
    'kebersihan' => 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300',
    'penerangan' => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-950/60 dark:text-yellow-300',
    default => 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300',
};
$label = match ($category) {
    'jalan' => 'Jalan Raya',
    'kebersihan' => 'Kebersihan',
    'penerangan' => 'Penerangan',
    default => 'Lainnya',
};
@endphp

<span {{ $attributes->merge(['class' => 'inline-flex rounded-full px-2.5 py-1 text-xs font-bold '.$classes]) }}>{{ $label }}</span>
