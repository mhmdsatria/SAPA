import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet.markercluster';
import 'leaflet.markercluster/dist/MarkerCluster.css';
import 'leaflet.markercluster/dist/MarkerCluster.Default.css';

const escapeHtml = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

const markerIcon = (color) => L.divIcon({
    className: '',
    html: `<div class="gis-marker" style="background:${escapeHtml(color)}"><span></span></div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30],
});

window.leafletMap = (config) => ({
    map: null,
    clusters: null,
    regions: null,
    locationMarker: null,
    accuracyCircle: null,
    loading: false,
    error: '',

    async init() {
        const element = this.$refs.canvas;
        if (!element || element.dataset.mapReady === 'true') return;

        element.dataset.mapReady = 'true';
        this.map = L.map(element, {
            zoomControl: true,
            preferCanvas: true,
        }).setView(
            [Number(config.center?.[0] ?? -6.917464), Number(config.center?.[1] ?? 107.619123)],
            Number(config.zoom ?? 12),
        );

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; OpenStreetMap contributors',
        }).addTo(this.map);

        this.clusters = L.markerClusterGroup({
            chunkedLoading: true,
            showCoverageOnHover: false,
            spiderfyOnMaxZoom: true,
            maxClusterRadius: 54,
        });
        this.regions = L.geoJSON(null, {
            style: {
                color: '#2563eb',
                weight: 2,
                fillColor: '#60a5fa',
                fillOpacity: 0.12,
            },
            onEachFeature: (feature, layer) => {
                layer.bindTooltip(escapeHtml(feature.properties?.name ?? 'Wilayah'));
                layer.on('click', () => this.map.fitBounds(layer.getBounds(), { maxZoom: 13 }));
            },
        });

        if (config.regionEndpoint) await this.loadRegions();
        if (config.endpoint) await this.loadComplaints();
        if (Array.isArray(config.points)) this.addDirectPoints(config.points);

        this.map.on('zoomend', () => this.syncLayers());
        this.syncLayers();

        window.addEventListener('wizard-map-location', (event) => {
            const detail = event.detail ?? {};
            this.setLocation(detail.latitude, detail.longitude, detail.accuracy);
        });

        setTimeout(() => this.map.invalidateSize(), 100);
    },

    async fetchJson(url) {
        const response = await fetch(url, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return response.json();
    },

    async loadRegions() {
        try {
            const geojson = await this.fetchJson(config.regionEndpoint);
            this.regions.clearLayers();
            this.regions.addData(geojson);
            if (config.fitRegions && this.regions.getLayers().length > 0) {
                this.map.fitBounds(this.regions.getBounds(), { padding: [20, 20] });
            }
        } catch (error) {
            console.error('Gagal memuat poligon wilayah:', error);
        }
    },

    async loadComplaints() {
        this.loading = true;
        this.error = '';

        try {
            const geojson = await this.fetchJson(config.endpoint);
            this.clusters.clearLayers();

            L.geoJSON(geojson, {
                pointToLayer: (feature, latlng) => L.marker(latlng, {
                    icon: markerIcon(feature.properties?.color ?? '#2563eb'),
                    keyboard: true,
                }),
                onEachFeature: (feature, layer) => {
                    const properties = feature.properties ?? {};
                    layer.bindPopup(`
                        <div style="min-width:220px">
                            <strong>${escapeHtml(properties.title)}</strong>
                            <div style="margin-top:6px;font-size:12px;opacity:.75">${escapeHtml(properties.category_label)} · ${escapeHtml(properties.created_at)}</div>
                            <p style="margin:8px 0;font-size:13px">${escapeHtml(properties.address)}</p>
                            <a href="${escapeHtml(properties.url)}" style="font-weight:700;color:#2563eb">Lihat detail</a>
                        </div>
                    `);
                },
            }).eachLayer((layer) => this.clusters.addLayer(layer));
        } catch (error) {
            this.error = 'Data peta gagal dimuat.';
            console.error('Gagal memuat laporan:', error);
        } finally {
            this.loading = false;
            this.syncLayers();
        }
    },

    addDirectPoints(points) {
        points.forEach((point) => {
            const marker = L.marker([Number(point.latitude), Number(point.longitude)], {
                icon: markerIcon(point.color ?? '#2563eb'),
            });

            if (point.popup) marker.bindPopup(escapeHtml(point.popup));
            this.clusters.addLayer(marker);
        });
    },

    setLocation(latitude, longitude, accuracy = null) {
        if (!this.map || latitude === null || longitude === null) return;
        const latlng = [Number(latitude), Number(longitude)];

        if (this.locationMarker) this.locationMarker.remove();
        if (this.accuracyCircle) this.accuracyCircle.remove();

        this.locationMarker = L.marker(latlng, {
            icon: markerIcon('#0f766e'),
            draggable: false,
        }).addTo(this.map);

        if (accuracy !== null && Number(accuracy) > 0) {
            this.accuracyCircle = L.circle(latlng, {
                radius: Number(accuracy),
                color: '#0f766e',
                fillOpacity: 0.08,
            }).addTo(this.map);
        }

        this.map.setView(latlng, Math.max(this.map.getZoom(), 17));
    },

    syncLayers() {
        if (!this.map) return;
        const threshold = Number(config.markerZoomThreshold ?? 12);
        const showMarkers = config.alwaysShowMarkers || this.map.getZoom() >= threshold;

        if (showMarkers && !this.map.hasLayer(this.clusters)) this.map.addLayer(this.clusters);
        if (!showMarkers && this.map.hasLayer(this.clusters)) this.map.removeLayer(this.clusters);

        if (!showMarkers && this.regions.getLayers().length > 0 && !this.map.hasLayer(this.regions)) {
            this.map.addLayer(this.regions);
        }
        if (showMarkers && this.map.hasLayer(this.regions)) this.map.removeLayer(this.regions);
    },
});
