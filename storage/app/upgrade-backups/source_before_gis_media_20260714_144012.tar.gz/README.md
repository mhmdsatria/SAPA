# LaporKota GIS

LaporKota GIS adalah sistem pelaporan publik berbasis lokasi yang dibangun dengan Laravel 13, Livewire, Tailwind CSS, Leaflet, MySQL Spatial, dan PWA. Paket ini mencakup ranah publik, autentikasi, wizard pelaporan tiga langkah, moderasi admin, peta berjenjang, marker clustering, komentar, upvote, penyensoran otomatis, deteksi duplikat spasial, ekspor PDF dan Excel, serta struktur admin daerah untuk pengembangan berikutnya.

## Fitur yang Tersedia

### Publik

- Beranda pada `/` dengan peta GIS, poligon wilayah, marker clustering, filter kategori, statistik, dan linimasa laporan terbaru.
- Wizard pelaporan pada `/lapor` dengan tiga langkah yang terdiri atas foto, lokasi GPS, dan detail laporan.
- Koordinat tidak disediakan sebagai input teks. Nilai hanya diterima oleh method Livewire setelah Geolocation API browser mengirimkan posisi perangkat.
- Reverse geocoding memakai Mapbox lebih dahulu, lalu Google Maps sebagai fallback, kemudian koordinat tekstual apabila kedua key tidak tersedia.
- Kompresi foto ke WebP, orientasi EXIF, pembatasan dimensi maksimal 1920 piksel, hash SHA-256, dan pembacaan tanggal pengambilan foto.
- Indikator foto lebih dari tujuh hari untuk pemeriksaan admin.
- Detail laporan pada `/keluhan/{slug}` dengan peta mini, komentar, dan upvote.
- Dashboard warga pada `/profil` untuk melihat status laporan milik sendiri.
- Opsi anonimitas nama pada tampilan publik.
- Penyensoran kata kasar pada deskripsi, patokan, alasan penolakan, dan komentar.

### Admin

- Dashboard statistik pada `/admin/dashboard`.
- Antrean laporan pending pada `/admin/laporan/masuk`.
- Aksi Approve, Reject, serta Edit & Approve.
- Indikator EXIF lama dan kemungkinan duplikat spasial.
- Arsip dan filter laporan pada `/admin/laporan/arsip`.
- Ekspor Excel dan PDF berdasarkan rentang tanggal, kategori, dan status.
- Peta pantau pada `/admin/peta` untuk seluruh status laporan sesuai kewenangan admin.
- Penyembunyian dan pemulihan komentar publik.
- Middleware admin dan policy pada laporan serta komentar.
- Struktur `region_id` dan `admin_daerah_assignments` untuk admin daerah.

### GIS dan PWA

- Kolom `POINT SRID 4326` pada laporan dengan spatial index.
- Kolom `POLYGON SRID 4326` pada wilayah dengan spatial index.
- Deteksi laporan pada radius 15 meter di hari yang sama menggunakan `ST_Distance_Sphere`.
- Stub assignment wilayah berbasis `ST_Contains` tersedia pada `GisService::assignRegionStub()` dan sengaja belum dipanggil dalam flow rilis awal.
- Poligon ditampilkan pada zoom rendah, sedangkan marker laporan ditampilkan pada zoom yang lebih dekat.
- Marker clustering memakai `Leaflet.markercluster`.
- Warna kategori terpusat pada `config/gis.php`.
- Manifest, ikon 192 dan 512 piksel, offline page, serta service worker tersedia pada folder `public`.

## Requirement Sistem

- PHP 8.3 atau lebih baru.
- Composer 2.x.
- Node.js 20 atau lebih baru dan npm.
- MySQL 8.x atau lebih baru.
- Ekstensi PHP `exif`, `fileinfo`, `gd`, `mbstring`, dan `pdo_mysql`.
- Browser modern yang mendukung Geolocation API.
- HTTPS pada server production agar Geolocation API dan instalasi PWA bekerja. `localhost` dan `127.0.0.1` diperbolehkan browser untuk pengembangan lokal.

MySQL 8.x wajib karena migration membuat kolom Geometry dengan SRID 4326, spatial index, dan query `ST_Distance_Sphere`. MariaDB atau SQLite tidak menjadi target paket ini.

## Struktur Proyek

```text
laravel_keluhan/
├── app/
│   ├── Exports/
│   │   └── ComplaintsExport.php
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Auth/
│   │   │   │   ├── GoogleAuthController.php
│   │   │   │   ├── OtpController.php
│   │   │   │   └── SessionController.php
│   │   │   ├── Controller.php
│   │   │   ├── ExportController.php
│   │   │   └── GisController.php
│   │   ├── Middleware/
│   │   │   └── EnsureIsAdmin.php
│   │   └── Requests/Auth/
│   │       ├── LoginRequest.php
│   │       ├── RegisterRequest.php
│   │       ├── SendOtpRequest.php
│   │       └── VerifyOtpRequest.php
│   ├── Livewire/
│   │   ├── Admin/
│   │   │   ├── ComplaintArchive.php
│   │   │   ├── Dashboard.php
│   │   │   ├── IncomingComplaints.php
│   │   │   └── MonitoringMap.php
│   │   └── Public/
│   │       ├── ComplaintDetail.php
│   │       ├── ComplaintWizard.php
│   │       ├── HomePage.php
│   │       └── ProfileDashboard.php
│   ├── Mail/
│   │   └── OtpCodeMail.php
│   ├── Models/
│   │   ├── AdminDaerahAssignment.php
│   │   ├── Comment.php
│   │   ├── Complaint.php
│   │   ├── LoginOtp.php
│   │   ├── Region.php
│   │   ├── Upvote.php
│   │   └── User.php
│   ├── Policies/
│   │   ├── CommentPolicy.php
│   │   └── ComplaintPolicy.php
│   ├── Providers/
│   │   └── AppServiceProvider.php
│   ├── Services/
│   │   ├── CensorService.php
│   │   ├── ComplaintService.php
│   │   ├── ExportService.php
│   │   ├── GisService.php
│   │   ├── ImageService.php
│   │   └── OtpService.php
│   └── Traits/
│       └── HasLocation.php
├── bootstrap/
│   ├── app.php
│   └── providers.php
├── config/
│   ├── app.php
│   ├── auth.php
│   ├── cache.php
│   ├── censor.php
│   ├── database.php
│   ├── filesystems.php
│   ├── gis.php
│   ├── logging.php
│   ├── mail.php
│   ├── queue.php
│   ├── services.php
│   └── session.php
├── database/
│   ├── factories/
│   │   ├── CommentFactory.php
│   │   ├── ComplaintFactory.php
│   │   ├── RegionFactory.php
│   │   ├── UpvoteFactory.php
│   │   └── UserFactory.php
│   ├── migrations/
│   │   ├── 2026_01_01_000001_create_users_table.php
│   │   ├── 2026_01_01_000002_create_regions_table.php
│   │   ├── 2026_01_01_000003_create_complaints_table.php
│   │   ├── 2026_01_01_000004_create_comments_table.php
│   │   ├── 2026_01_01_000005_create_upvotes_table.php
│   │   ├── 2026_01_01_000006_create_admin_daerah_assignments_table.php
│   │   └── 2026_01_01_000007_create_login_otps_table.php
│   └── seeders/
│       └── DatabaseSeeder.php
├── public/
│   ├── icons/
│   │   ├── icon-192.png
│   │   └── icon-512.png
│   ├── index.php
│   ├── manifest.json
│   ├── offline.html
│   └── service-worker.js
├── resources/
│   ├── css/
│   │   └── app.css
│   ├── js/
│   │   ├── app.js
│   │   ├── bootstrap.js
│   │   └── gis-map.js
│   └── views/
│       ├── auth/
│       ├── components/
│       │   ├── badge/
│       │   ├── complaint/
│       │   ├── layouts/
│       │   ├── map/
│       │   └── ui/
│       ├── exports/
│       ├── layouts/
│       ├── livewire/admin/
│       ├── livewire/public/
│       └── mail/
├── routes/
│   ├── console.php
│   └── web.php
├── tests/
│   ├── Feature/PublicRouteSmokeTest.php
│   ├── Unit/CensorServiceTest.php
│   └── TestCase.php
├── .env.example
├── artisan
├── composer.json
├── install.sh
├── package.json
├── phpunit.xml
├── tailwind.config.js
└── vite.config.js
```

## Instalasi Otomatis

Installer mengasumsikan MySQL berjalan pada `127.0.0.1:3306`, database bernama `laravel_keluhan`, username `root`, dan password kosong.

```bash
unzip laravel_keluhan.zip
cd laravel_keluhan
chmod +x install.sh
bash install.sh
```

Installer akan melakukan tindakan berikut:

1. Memeriksa PHP, ekstensi PHP, Composer, Node.js, npm, dan MySQL.
2. Memastikan versi utama MySQL minimal 8.
3. Membuat database `laravel_keluhan` apabila belum tersedia.
4. Membuat `.env` dari `.env.example`.
5. Menjalankan `composer install`.
6. Menjalankan `npm install`.
7. Membuat application key.
8. Membuat symbolic link storage.
9. Menjalankan migration, spatial index, dan seeder.
10. Menjalankan `npm run build`.
11. Membersihkan cache aplikasi.

Setelah installer selesai:

```bash
php artisan serve
```

Buka `http://127.0.0.1:8000`.

## Instalasi Manual

### 1. Buat database

```sql
CREATE DATABASE laravel_keluhan
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
```

### 2. Siapkan environment

```bash
cp .env.example .env
```

Konfigurasi database default:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=laravel_keluhan
DB_USERNAME=root
DB_PASSWORD=

MAPBOX_API_KEY=
GOOGLE_MAPS_API_KEY=
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
```

### 3. Pasang dependensi dan key

```bash
composer install
npm install
php artisan key:generate
php artisan storage:link
```

### 4. Jalankan migration dan seeder

```bash
php artisan migrate --seed
```

Periksa spatial index apabila diperlukan:

```sql
SHOW INDEX FROM complaints WHERE Index_type = 'SPATIAL';
SHOW INDEX FROM regions WHERE Index_type = 'SPATIAL';
```

### 5. Jalankan mode pengembangan

Terminal pertama:

```bash
php artisan serve
```

Terminal kedua:

```bash
npm run dev
```

### 6. Bangun aset production

```bash
npm run build
php artisan optimize
```

## Akun Seeder

### Super Admin

```text
Email: admin@laporkota.test
Password: Admin123!
```

### Admin Daerah Demonstrasi

```text
Email: admin.bandung@laporkota.test
Password: Admin123!
```

### Warga

```text
Email: warga@laporkota.test
Password: Warga123!
```

Ubah seluruh kredensial seed sebelum sistem dipublikasikan.

## API Key Mapbox

1. Buka halaman akun Mapbox: https://account.mapbox.com/
2. Buat access token.
3. Isi token pada `.env`:

```env
MAPBOX_API_KEY=pk_xxxxxxxxxxxxxxxxx
```

Dokumentasi resmi Geocoding API:

https://docs.mapbox.com/api/search/geocoding/

## API Key Google Maps

1. Buka Google Cloud Console: https://console.cloud.google.com/
2. Buat atau pilih project.
3. Aktifkan Geocoding API.
4. Buat API key dan batasi key berdasarkan domain serta API yang digunakan.
5. Isi `.env`:

```env
GOOGLE_MAPS_API_KEY=xxxxxxxxxxxxxxxxx
```

Dokumentasi resmi:

https://developers.google.com/maps/documentation/geocoding/get-api-key

Mapbox diprioritaskan. Google Maps digunakan sebagai fallback apabila `MAPBOX_API_KEY` kosong atau request Mapbox gagal.

## Google SSO

1. Buat OAuth 2.0 Client ID pada Google Cloud Console.
2. Tambahkan authorized redirect URI:

```text
http://127.0.0.1:8000/auth/google/callback
```

3. Isi `.env`:

```env
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI="${APP_URL}/auth/google/callback"
```

Dokumentasi resmi Google OAuth:

https://developers.google.com/identity/protocols/oauth2/web-server

## Email OTP

Default mailer adalah `log`. Pada mode lokal, kode OTP juga ditampilkan sebagai pesan debug setelah permintaan OTP. Untuk pengiriman email nyata, atur konfigurasi mail pada `.env`, misalnya SMTP:

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=your-user
MAIL_PASSWORD=your-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@example.com
MAIL_FROM_NAME="LaporKota GIS"
```

## WhatsApp OTP

Integrasi WhatsApp memakai webhook generik agar dapat dihubungkan ke provider resmi yang dipilih instansi. Isi:

```env
WHATSAPP_WEBHOOK_URL=https://provider.example.com/messages
WHATSAPP_WEBHOOK_TOKEN=your-token
WHATSAPP_SENDER_ID=your-sender-id
```

Payload yang dikirim oleh `OtpService`:

```json
{
  "to": "628xxxxxxxxxx",
  "sender_id": "your-sender-id",
  "message": "Kode OTP LaporKota GIS Anda: 123456. Berlaku 5 menit."
}
```

Apabila webhook kosong, kode OTP WhatsApp dicatat ke log Laravel pada mode lokal.

## Konfigurasi Sensor Kata

Daftar kata terdapat pada:

```text
config/censor.php
```

Semua kata yang terdeteksi diganti menjadi `***`. Tambahkan atau kurangi kata sesuai kebijakan moderasi instansi.

## Konfigurasi Warna dan Radius GIS

Warna marker dan parameter GIS terdapat pada:

```text
config/gis.php
```

Default warna:

- Jalan: merah `#dc2626`
- Kebersihan: hijau `#16a34a`
- Penerangan: kuning `#eab308`
- Lainnya: biru `#2563eb`

Radius deteksi duplikat dapat diubah melalui `.env`:

```env
GIS_DUPLICATE_RADIUS_METERS=15
```

## Menjalankan Pengujian

```bash
php artisan test
```

Format kode:

```bash
./vendor/bin/pint
```

## Catatan Production

- Gunakan HTTPS.
- Ubah `APP_ENV=production` dan `APP_DEBUG=false`.
- Gunakan akun database dengan privilege minimum, bukan `root`.
- Atur queue worker apabila mail dan notifikasi dipindahkan ke queue.
- Batasi API key Mapbox dan Google berdasarkan domain serta API.
- Ganti kredensial seluruh akun seeder.
- Atur backup database dan storage foto.
- Jalankan `php artisan optimize` setelah deployment.
- Pastikan document root web server menunjuk ke folder `public`.
